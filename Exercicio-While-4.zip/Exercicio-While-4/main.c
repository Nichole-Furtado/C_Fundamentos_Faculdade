/*#include <stdio.h>

int main(void) { // 5
  int x, n, total, i=2;

  printf("Digite o primeiro número inteiro para realizar potência: ");
  scanf("%d", &x);

  printf("Digite o segundo número inteiro para realizar potência: ");
  scanf("%d", &n);
total= x;
  
  while (i <= n) {

    total = total * x;
    
    i++;
  }
  printf("O resultado da potência é: %i", total);

  return 0;
}*/
int main(void) { // 1 x 5
  int x, n, total=1,i=1;

  printf("Digite o primeiro número inteiro para realizar potência: ");
  scanf("%d", &x);

  printf("Digite o segundo número inteiro para realizar potência: ");
  scanf("%d", &n);


  while (i <= n) {

    total = total * x;

    i++;
  }
  printf("O resultado da potência é: %i", total);

  return 0;
}