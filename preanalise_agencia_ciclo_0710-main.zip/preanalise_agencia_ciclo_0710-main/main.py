import time
import fluid
from prefect import flow, task
from prefect.blocks.system import String
import severidades
import misc
from smtp_mail import send_reports_to_multiple_contacts
from datetime import datetime as dtt
from datetime import timedelta as tdlt
from data_processing import (membros_proposta,
                             grupo_economico,
                             patrimonio,
                             reciprocidade,
                             comprometimento,
                             saldos,
                             exposicao)


@flow(name='preanalise_agencia_ciclo_0710', log_prints=True)
def main_fn():

    failure_mail_contacts = String.load("failure-contacts-preanalise").value

    start_time = dtt.now()
    end_time = start_time + tdlt(minutes=30)

    while dtt.now() < end_time:

        try:

            df = fluid.get_processes()

            print(f"Processo(s) aguardando consultas: {str(df.shape[0])}")

            for index, process in df.iterrows():

                @task(name=f'consulta_{process["Número do processo"]}')
                def consulta():

                    # iniciar processo
                    process_id = int(process['Número do processo'])
                    doc_proponente = process['CPF Proponente'] + process['CNPJ Proponente']
                    print("- - - - - - - - - - - - - - - - -")
                    print("")
                    print(f"Iniciando processo {str(process_id)}")
                    print("")

                    node = fluid.get_next_node(process_id=process_id)

                    # envolvidos
                    print("-- Gerando lista de envolvidos --")
                    df_membros = membros_proposta.get_membros(process_id=process_id, doc_proponente=doc_proponente)

                    # exposicao
                    print("-- Gerando análise de exposição")
                    df_exposicao = exposicao.get_exposicao_grupo(df_membros=df_membros)
                    html_exposicao = misc.generate_html_from_df(dataframes=[df_exposicao])
                    fluid.update_fields_exposicao(process_id=process_id,
                                                  html=html_exposicao,
                                                  node=node,
                                                  df_exposicao=df_exposicao)

                    # severidades
                    print("-- Gerando análise de severidades")
                    df_severidades = severidades.get_severidades_grupo(df_membros=df_membros)
                    html_severidades = misc.generate_html_from_df(dataframes=[df_severidades])
                    fluid.update_fields_severidades(process_id=process_id,
                                                    html=html_severidades,
                                                    df_severidades=df_severidades, node=node)

                    # saldos
                    print("-- Gerando análise de saldos")
                    df_saldos = saldos.get_saldos_grupo(df_membros=df_membros)
                    html_saldos = misc.generate_html_from_df(dataframes=[df_saldos])
                    fluid.update_fields_saldos(process_id=process_id,
                                               html=html_saldos, node=node)

                    # comprometimento
                    print("-- Gerando análise de comprometimento")
                    df_comprometimento = comprometimento.get_comp_grupo(doc_list=df_membros['doc_c'].tolist(),
                                                                        df_membros=df_membros)
                    html_comprometimento = misc.generate_html_from_df(dataframes=[df_comprometimento])
                    fluid.update_fields_comprometimento(process_id=process_id,
                                                        html=html_comprometimento, node=node)

                    # compor infos de reciprocidade
                    print("-- Gerando análise de reciprocidade")
                    df_reciprocidade = reciprocidade.get_reciprocidade_grupo(df_membros=df_membros)
                    html_reciprocidade = misc.generate_html_from_df(dataframes=[df_reciprocidade])
                    fluid.update_fields_reciprocidade(process_id=process_id, html=html_reciprocidade, node=node)

                    # patrimonio
                    print("-- Gerado análise de patrimônio --")
                    patrimonio_dfs = patrimonio.get_patrimonio_grupo(df_membros=df_membros)
                    html_patrimonio = misc.generate_html_from_df(dataframes=patrimonio_dfs)
                    fluid.update_fields_patrimonio(process_id=process_id, html=html_patrimonio, node=node)

                    # grupo eco
                    print("-- Gerando membros do grupo econômico --")
                    df_grupo_eco = grupo_economico.get_grupo(doc_proponente)
                    html_grupo_eco = misc.generate_html_from_df(dataframes=[df_grupo_eco])
                    fluid.update_fields_grupo_eco(process_id=process_id, html=html_grupo_eco, node=node)

                    # protocolar processo
                    dataframes_protocol = [df_grupo_eco,
                                           df_reciprocidade,
                                           df_comprometimento,
                                           df_severidades,
                                           df_saldos,
                                           df_exposicao]
                    for df_pat in patrimonio_dfs:
                        dataframes_protocol.append(df_pat)

                    html_all_dfs = misc.generate_html_from_df(dataframes=dataframes_protocol)
                    fluid.protocolar(process_id=process_id, parecer=html_all_dfs)

                # noinspection PyBroadException
                try:
                    consulta()
                except Exception as err_proc:
                    print(f"Erro na consulta {process}")
                    print(Exception)
                    send_reports_to_multiple_contacts(subject=f'Falha na pré análise #'
                                                              f'{str(process["Número do processo"])}',
                                                      body=f'Dados: \n{process}\nErro: {err_proc}',
                                                      mail_list=failure_mail_contacts,
                                                      file_paths=[])
                    continue

            time.sleep(10)
            if dtt.now() > end_time:
                print("")
                print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
                print("Tempo da execução esgotado. O próximo gatilho iniciará em breve.")
                print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")

        except Exception as err:
            print("Falha ao gerar consultas")
            print(err)


if __name__ == "__main__":
    main_fn()
