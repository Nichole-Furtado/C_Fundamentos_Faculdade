import re
import pandas as pd
from data_processing import datalake
import math


def get_severidades_grupo(df_membros):
    df_restritivos = get_restritivos_from_datalake(df_membros=df_membros)
    df_restritivos = keep_only_relevant_rows(df_restritivos=df_restritivos)
    df_restritivos = normalize_values_to_float(df=df_restritivos)
    df_restritivos = get_highest_record_by_id(df_restritivos=df_restritivos)

    df_severidades = pd.DataFrame()
    df_severidades['CPF/CNPJ'] = None
    df_severidades['Nome'] = None
    df_severidades['Restritivo Interno'] = None
    df_severidades['SCR'] = None
    df_severidades['Serasa'] = None
    df_severidades['SCPC'] = None
    df_severidades['Receita Federal'] = None

    for idx, membro in df_membros.iterrows():

        df_restritivos_aux = df_restritivos[df_restritivos['cpf_cnpj_configurado'] == membro['doc_c']].reset_index(drop=True)

        if df_restritivos_aux.shape[0] == 0:

            not_located_msg = "Não localizado"

            new_row = {'CPF/CNPJ': membro['doc_c'],
                       'Nome': membro['name'],
                       'Restritivo Interno': not_located_msg,
                       'SCR': not_located_msg,
                       'Serasa': not_located_msg,
                       'SCPC': not_located_msg,
                       'Receita Federal': not_located_msg}
        else:
            new_row = {'CPF/CNPJ': membro['doc_c'],
                       'Nome': membro['name'],
                       'Restritivo Interno': str(df_restritivos_aux.at[0, 'vlr_severidade_interna']),
                       'SCR': str(df_restritivos_aux.at[0, 'scr_severidade_externa']),
                       'Serasa': str(df_restritivos_aux.at[0, 'serasa_severidade_externa']),
                       'SCPC': str(df_restritivos_aux.at[0, 'scpc_severidade_externa']),
                       'Receita Federal': str(df_restritivos_aux.at[0, 'rec_federal_severidade_externa'])}

        df_severidades.loc[len(df_severidades)] = new_row

    return df_severidades


def get_restritivos_from_datalake(df_membros):
    return datalake.get_data_in_datalake(arg_list=df_membros['doc_c'].tolist(), table_name='restritivos_bureau_atual', target_column='cpf_cnpj_configurado')


def keep_only_relevant_rows(df_restritivos):
    cols_to_keep = ["cpf_cnpj_configurado", "vlr_severidade_interna", "scr_severidade_externa",
                    "serasa_severidade_externa", "scpc_severidade_externa", "rec_federal_severidade_externa"]
    return df_restritivos[cols_to_keep]


def normalize_values_to_float(df):
    cols = list(df.columns)
    cols.remove("cpf_cnpj_configurado")

    for idx, row in df.iterrows():
        for col in cols:
            # noinspection PyBroadException
            try:
                current_value = float(row[col])
                if math.isnan(current_value):
                    current_value = 0.0
            except:
                current_value = 0.0

            str_value = re.sub(string=str(current_value), pattern=r"\.\d+$", repl='')
            df.at[idx, col] = str_value

    return df


def get_highest_record_by_id(df_restritivos):
    df_max = df_restritivos.groupby('cpf_cnpj_configurado').max().reset_index()
    return df_max
