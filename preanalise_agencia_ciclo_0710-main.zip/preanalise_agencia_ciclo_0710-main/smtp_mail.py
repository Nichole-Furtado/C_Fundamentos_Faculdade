import os
import smtplib
import time
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from prefect.blocks.system import JSON
from prefect import task


class SMTPConfig:
    config = JSON.load("smtp-server-config").value

    def __init__(self):
        self.server_url = SMTPConfig.config['server_url']
        self.port = SMTPConfig.config['port']


def get_credential_owa_mail_acc():
    from prefect.blocks.system import JSON, Secret

    json_block = JSON.load("rpa-0710-conta-email").value
    secret_block = Secret.load(json_block['secret_block'])
    user = json_block['id']
    password = secret_block.get()

    return {'user': user, 'password': password}


@task(name='send_mail')
def send_mail(receiver_email: str, subject: str, body: str, file_paths: list, credentials: dict):
    message = MIMEMultipart()
    message['From'] = credentials['user']
    message['To'] = receiver_email
    message['Cc'] = ''
    message['Subject'] = subject

    message.attach(MIMEText(body, 'plain'))

    for file_path in file_paths:
        attachment = open(file_path, 'rb')

        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        file_name = os.path.basename(file_path)  # Extract the file name from the file path
        part.add_header('Content-Disposition', "attachment; filename= %s" % file_name)

        message.attach(part)

    smtp_server = smtp_config.server_url
    smtp_port = int(smtp_config.port)

    server = smtplib.SMTP(smtp_server, smtp_port)
    server.starttls()
    server.login(password=credentials['password'], user=credentials['user'])

    server.sendmail(credentials['user'], receiver_email, message.as_string())
    # noinspection PyBroadException
    try:
        server.quit()
    except Exception as err:
        "Erro ao fechar a conexão SMTP"
        print(err)


def send_reports_to_multiple_contacts(mail_list: str, file_paths: list, subject: str, body: str):
    email_list = mail_list.split(';')

    credentials = get_credential_owa_mail_acc()

    for email in email_list:
        send_mail(receiver_email=email, file_paths=file_paths, subject=subject, body=body, credentials=credentials)
        time.sleep(1)


smtp_config = SMTPConfig()
