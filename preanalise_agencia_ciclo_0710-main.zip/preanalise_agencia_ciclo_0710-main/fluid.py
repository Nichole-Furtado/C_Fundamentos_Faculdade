import datetime
import re
import time
from fluid_api import fluid_api_requests
from prefect import task

node_name_comite_ag = "Informações Complementares"
token_v2 = fluid_api_requests.get_fluid_token_v2()


@task(name='get_processes', log_prints=True)
def get_processes():
    max_tries = 3
    tries = 0
    while tries < max_tries:
        try:
            tries += 1
            id_report = 989
            final_date = datetime.datetime.now()
            start_date = final_date - datetime.timedelta(days=120)
            final_date = final_date.strftime(format='%Y-%m-%d')
            start_date = start_date.strftime(format='%Y-%m-%d')
            situation = 1
            page = 1
            (df_report,
             total,
             number_of_pages,
             status_code) = fluid_api_requests.process_reports_v2(id_report=id_report,
                                                                  start_date=start_date,
                                                                  final_date=final_date,
                                                                  situation=situation,
                                                                  alternative_token=token_v2,
                                                                  page=page)

            return df_report
        except Exception as err:

            print("Falha ao gerar relatório de processos")
            print(err)
            time.sleep(5)


def update_fields_grupo_eco(process_id: int, html: str, node: int):
    fields_dict = {"13730": html}
    fluid_api_requests.save_fields_v2(process_id=process_id,
                                      token_v2=token_v2,
                                      fields_dict=fields_dict,
                                      node=node,
                                      action=0,
                                      should_perform_action=True)


def update_fields_patrimonio(process_id: int, html: str, node: int):
    fields_dict = {"13790": html}
    fluid_api_requests.save_fields_v2(process_id=process_id,
                                      token_v2=token_v2,
                                      fields_dict=fields_dict,
                                      node=node,
                                      action=0,
                                      should_perform_action=True)


def update_fields_reciprocidade(process_id: int, html: str, node: int):
    fields_dict = {"16467": html}
    fluid_api_requests.save_fields_v2(process_id=process_id,
                                      token_v2=token_v2,
                                      fields_dict=fields_dict,
                                      node=node,
                                      action=0,
                                      should_perform_action=True)


def update_fields_comprometimento(process_id: int, html: str, node: int):
    fields_dict = {"16468": html}
    fluid_api_requests.save_fields_v2(process_id=process_id,
                                      token_v2=token_v2,
                                      fields_dict=fields_dict,
                                      node=node,
                                      action=0,
                                      should_perform_action=True)


def update_fields_saldos(process_id: int, html: str, node: int):
    fields_dict = {"16499": html}
    fluid_api_requests.save_fields_v2(process_id=process_id,
                                      token_v2=token_v2,
                                      fields_dict=fields_dict,
                                      node=node,
                                      action=0,
                                      should_perform_action=True)


def update_fields_exposicao(process_id: int, html: str, node: int, df_exposicao):
    finantial_value = df_exposicao.at[0, df_exposicao.columns[0]]
    finantial_value = re.sub(pattern=r'[^\d,.]', string=finantial_value, repl='')
    fields_dict = {"21646": html, "12268": finantial_value}
    fluid_api_requests.save_fields_v2(process_id=process_id,
                                      token_v2=token_v2,
                                      fields_dict=fields_dict,
                                      node=node,
                                      action=0,
                                      should_perform_action=True)


def update_fields_severidades(df_severidades, process_id: int, html: str, node: int):
    cols = list(df_severidades.columns)
    cols.remove("CPF/CNPJ")
    cols.remove("Nome")
    maior_severidade = 0.0
    for index, row in df_severidades.iterrows():
        for col in cols:
            # noinspection PyBroadException
            try:
                this_sev = float(row[col])
            except:
                this_sev = 0
            if this_sev > maior_severidade:
                maior_severidade = float(row[col])
    grau_sev = 'Severidade de 0'
    if 0 < maior_severidade < 8:
        grau_sev = 'Severidade de 1 a 7'
    if maior_severidade == 8:
        grau_sev = 'Severidade 8'
    if maior_severidade == 9:
        grau_sev = 'Severidade 9'
    fields_dict = {"16500": html,
                   "9803": grau_sev}
    fluid_api_requests.save_fields_v2(process_id=process_id,
                                      token_v2=token_v2,
                                      fields_dict=fields_dict,
                                      node=node,
                                      action=0,
                                      should_perform_action=True)


def get_next_node(process_id: int):
    df_nodes, status = fluid_api_requests.get_next_nodes(token_v2=token_v2, process_id=process_id)
    next_node = df_nodes.at[0, 'node']
    return int(next_node)


def protocolar(process_id: int, parecer: str):
    df_next_nodes, status_code = fluid_api_requests.get_next_nodes(token_v2=token_v2, process_id=process_id)
    work_id = int(df_next_nodes[df_next_nodes['label'] == node_name_comite_ag].reset_index(drop=True).at[0, 'node'])

    fluid_api_requests.protocol(process_id=process_id,
                                token_v2=token_v2,
                                emp_destino=0,
                                resp_destino=0,
                                parecer=parecer,
                                acao=0,
                                parecer_restrito=0,
                                work_id=work_id,
                                should_perform_action=True,
                                tempo=0)
    pass


def get_avalistas_table(process_id: int):
    table_id = 13743
    df_avalistas, status = fluid_api_requests.get_table_in_form(table_id=table_id,
                                                                process_id=process_id,
                                                                use_strings_as_column_names=True,
                                                                token_v2=token_v2)
    return df_avalistas
