import re
from prefect.blocks.system import Secret, JSON


def get_datalake_api_credentials():
    json_block = JSON.load('datalake-api-config').value
    user = json_block['user_name']
    next_block = json_block['password_block']
    password = Secret.load(next_block).get()
    credential = Credential(in_user=user, in_password=password)
    return credential


def generate_html_from_df(dataframes: list):
    html = ''
    for df in dataframes:
        idx_t = 0
        df = df.reset_index(drop=True)
        aux_html = df.to_html(index=False)
        aux_html = aux_html.replace('<table', '<table style="margin:auto; border-collapse: collapse; width: 100%; '
                                              'font-family: Arial, sans-serif; color: #333333;"')
        aux_html = aux_html.replace('<th', '<th style="background-color: #64c832; border: 1px solid #dddddd; padding: '
                                           '8px; text-align: center;"')
        pattern = r'.+;\W.+ead>'
        aux_html = re.sub(pattern=pattern, string=aux_html, repl='')
        aux_html = aux_html.replace('<td', '<td style="border: 1px solid #dddddd; padding: 8px; text-align: center;"')
        aux_html = aux_html.replace('<tr:nth-child(even)', '<tr style="background-color: #f9f9f9"')
        aux_html = aux_html.replace('<tr:hover', '<tr style="background-color: #dddddd"')
        html += aux_html + "</br>"
        idx_t += 1

    html = insert_into_html_body(html)

    return html


def insert_into_html_body(html):

    html = (f"<!DOCTYPE html>"
            "<html>"
            "<head>"
            "</head>"
            "<body>"
            f"{html}"
            "</body>"
            "</html>")
    spacing_pattern = r'\s{2,100}'
    html = re.sub(pattern=spacing_pattern, string=html, repl='')
    line_break_pattern = r'\n'
    html = re.sub(pattern=line_break_pattern, string=html, repl='')
    return html


def is_float(string):
    try:
        float(string)
        return True
    except ValueError:
        return False


class Credential:
    def __init__(self, in_user, in_password):
        self.username = in_user
        self.password = in_password
