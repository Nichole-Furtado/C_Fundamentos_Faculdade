from data_processing import datalake
import pandas as pd
import locale

locale.setlocale(locale.LC_ALL, 'pt_BR.UTF-8')


def get_saldos_grupo(df_membros):
    df_base_rel = get_base_rel(df_membros=df_membros)
    df_base_rel = keep_only_sld_rows(df=df_base_rel)

    df_saldos = pd.DataFrame()
    df_saldos['CPF/CNPJ'] = None
    df_saldos['Nome'] = None
    df_saldos['Fundos'] = None
    df_saldos['Depósito a prazo'] = None
    df_saldos['Depósito a vista'] = None
    df_saldos['Capital social'] = None
    df_saldos['Previdência'] = None
    df_saldos['Poupança'] = None
    df_saldos['LCA'] = None
    df_saldos['LCI'] = None
    df_saldos['Total'] = None

    for index, membro in df_membros.iterrows():

        df_base_rel_aux = df_base_rel[df_base_rel['num_cpf_cnpj'] == membro['doc_s']].reset_index(drop=True)

        if df_base_rel_aux.shape[0] == 0:
            cols = list(df_base_rel_aux.columns)
            cols.remove("num_cpf_cnpj")
            new_row = {'num_cpf_cnpj': membro['doc_s']}
            for col in cols:
                new_row[col] = "0.0"
            df_base_rel_aux.loc[0] = new_row

        new_row = {'CPF/CNPJ': membro['doc_c'],
                   'Nome': membro['name'],
                   'Fundos': locale.currency(float(df_base_rel_aux.at[0, 'sld_fundos']), grouping=True, symbol=True),
                   'Depósito a prazo': locale.currency(float(df_base_rel_aux.at[0, 'sld_dep_a_prazo']), grouping=True, symbol=True),
                   'Depósito a vista': locale.currency(float(df_base_rel_aux.at[0, 'sld_dep_a_vista']), grouping=True, symbol=True),
                   'Capital social': locale.currency(float(df_base_rel_aux.at[0, 'sld_capital_social']), grouping=True, symbol=True),
                   'Previdência': locale.currency(float(df_base_rel_aux.at[0, 'sld_previdencia']), grouping=True, symbol=True),
                   'Poupança': locale.currency(float(df_base_rel_aux.at[0, 'sld_poupanca']), grouping=True, symbol=True),
                   'LCA': locale.currency(float(df_base_rel_aux.at[0, 'sld_lca']), grouping=True, symbol=True),
                   'LCI': locale.currency(float(df_base_rel_aux.at[0, 'sld_lci']), grouping=True, symbol=True),
                   'Total': locale.currency(get_sum_of_values_in_row(df_base_rel_aux.iloc[0]), grouping=True, symbol=True)}
        df_saldos.loc[len(df_saldos)] = new_row

    return df_saldos


def get_base_rel(df_membros):

    df_base_rel = datalake.get_data_in_datalake(arg_list=df_membros['doc_s'].tolist(),
                                                table_name='base_relacionamento_atual',
                                                target_column='num_cpf_cnpj')
    return df_base_rel


def keep_only_sld_rows(df):
    cols_to_keep = ['num_cpf_cnpj', 'sld_fundos', 'sld_dep_a_prazo', 'sld_capital_social', 'sld_dep_a_vista', 'sld_previdencia', 'sld_poupanca', 'sld_lca', 'sld_lci']
    if df.shape[0] > 0:
        return df[cols_to_keep]
    else:
        df = pd.DataFrame()
        for col in cols_to_keep:
            df[col] = None
        return df


def get_sum_of_values_in_row(row):
    value: float = 0
    for key in row.keys():
        if 'sld' in key:
            # noinspection PyBroadException
            try:
                value += float(row[key])
            except:
                continue

    return value