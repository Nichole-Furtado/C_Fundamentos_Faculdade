import copy
import pandas as pd
from data_processing import datalake
import warnings
import datetime
import locale


locale.setlocale(locale.LC_ALL, 'pt_BR.UTF-8')


def get_comp_grupo(doc_list: list, df_membros):
    df_comprometimento_grupo = pd.DataFrame()
    df_comprometimento_grupo['CPF/CNPJ'] = None
    df_comprometimento_grupo['Nome'] = None
    df_comprometimento_grupo['Comprometimento Anual (SCR) - até 360 dias'] = None
    df_comprometimento_grupo['Comprometimento 31-60 (SCR)'] = None
    df_comprometimento_grupo['Saldo devedor de CPR (todos)'] = None
    df_comprometimento_grupo['Data do último vencimento de CPR'] = None
    df_comprometimento_grupo['Qtd. de CPRs'] = None
    df_comprometimento_grupo['Comprometimento a Vencer (SCR + CPR)'] = None

    df_scr = datalake.get_data_in_datalake(arg_list=doc_list, table_name='listagem_scr_atual',
                                           target_column='cpf_cnpj_configurado')
    if df_scr.shape[0] == 0:
        data = {"Nenhum membro da proposta possui dados de SCR":
                "É possível que as contas de envolvidos sejam muito recentes ou não tenham dado aceite a consulta."}
        df_comprometimento_grupo = pd.DataFrame(data, index=[0])
        return df_comprometimento_grupo

    df_scr = get_scr_flattened(df_scr=df_scr)

    df_cpr = datalake.get_data_in_datalake(arg_list=doc_list, table_name='agro_endividamento_cpr_atual',
                                           target_column='cpf_cnpj')
    df_cpr = get_cpr_flattened(doc_list=doc_list, df_cpr=df_cpr)

    for idx, membro in df_membros.iterrows():

        df_scr_aux = df_scr[df_scr['cpf_cnpj'] == membro['doc_s']].reset_index(drop=True)
        df_cpr_aux = df_cpr[df_cpr['doc'] == membro['doc_c']].reset_index(drop=True)

        if df_scr_aux.shape[0] > 0:
            scr_360 = (float(df_scr_aux.at[0, 'cred_a_vencer_30']) +
                       float(df_scr_aux.at[0, 'cred_a_vencer_31_60']) +
                       float(df_scr_aux.at[0, 'cred_a_vencer_61_90']) +
                       float(df_scr_aux.at[0, 'cred_a_vencer_91_180']) +
                       float(df_scr_aux.at[0, 'cred_a_vencer_181_360']))
            scr_360 = locale.currency(float(scr_360), grouping=True, symbol=True)
        else:
            scr_360 = 'Não localizado'

        total_cpr = locale.currency(float(df_cpr_aux.at[0, 'saldo_devedor']), grouping=True, symbol=True)

        last_date_cpr = df_cpr_aux.at[0, 'ultima_data']

        qtd_ops = df_cpr_aux.at[0, 'qtd_ops']

        total_comp = 0
        for idx_c, scr in df_scr_aux.iterrows():
            for col in df_scr_aux.columns:
                if col == 'cpf_cnpj':
                    continue
                total_comp += float(scr[col])

        if df_scr_aux.shape[0] > 0:
            scr_mensal = float(df_scr_aux.at[0, 'cred_a_vencer_31_60'])
            scr_mensal = locale.currency(scr_mensal, grouping=True, symbol=True)
        else:
            scr_mensal = "Não localizado"
        total_comp += float(df_cpr_aux.at[0, 'saldo_devedor'])
        total_comp = locale.currency(total_comp, grouping=True, symbol=True)
        new_row = {'CPF/CNPJ': membro['doc_c'],
                   'Nome': membro['name'],
                   'Comprometimento Anual (SCR) - até 360 dias': scr_360,
                   'Comprometimento 31-60 (SCR)': scr_mensal,
                   'Saldo devedor de CPR (todos)': total_cpr,
                   'Data do último vencimento de CPR': last_date_cpr,
                   'Qtd. de CPRs': qtd_ops,
                   'Comprometimento a Vencer (SCR + CPR)': total_comp}

        df_comprometimento_grupo.loc[len(df_comprometimento_grupo)] = new_row

    return df_comprometimento_grupo


def get_scr_flattened(df_scr):

    cols_to_float = ['cred_a_vencer_30',
                     'cred_a_vencer_31_60',
                     'cred_a_vencer_61_90',
                     'cred_a_vencer_91_180',
                     'cred_a_vencer_181_360',
                     'cred_a_vencer_361_720',
                     'cred_a_vencer_721_1080',
                     'cred_a_vencer_1081_1440',
                     'cred_a_vencer_1441_1800',
                     'cred_a_vencer_1801_5400',
                     'cred_a_vencer_ac_5400',
                     'cred_a_vencer_prazo_ind']

    cols_to_keep = cols_to_float[:]
    cols_to_keep.append('cpf_cnpj')

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=FutureWarning)
        df_flat_scr = df_scr[cols_to_keep].copy()
        df_flat_scr.loc[:, cols_to_float] = df_flat_scr.loc[:, cols_to_float].astype(float)
        df_flat_scr = df_flat_scr.fillna(0).infer_objects(copy=False)
        df_flat_scr = df_flat_scr.groupby('cpf_cnpj').sum().reset_index()

    return df_flat_scr


def get_cpr_flattened(doc_list: list, df_cpr):
    df_flat_cpr = pd.DataFrame()
    df_flat_cpr['doc'] = None
    df_flat_cpr['saldo_devedor'] = None
    df_flat_cpr['ultima_data'] = None
    df_flat_cpr['qtd_ops'] = None

    for doc in doc_list:
        # noinspection PyBroadException
        try:
            df_cpr_aux = df_cpr[df_cpr['cpf_cnpj'] == doc]
        except:
            df_cpr_aux = pd.DataFrame()

        if not df_cpr_aux.shape[0] > 0:
            new_row = {'doc': doc, 'saldo_devedor': '0', 'ultima_data': 'Não localizado', 'qtd_ops': '0'}
            df_flat_cpr.loc[len(df_flat_cpr)] = new_row
            continue

        right_now = datetime.datetime.now()
        total_sum_owed: float = 0
        op_count: float = 0
        last_date = datetime.datetime(year=1900, month=1, day=1, hour=0, minute=0, second=1)

        for idx, cpr in df_cpr_aux.iterrows():

            date_str = cpr['data_vencimento']
            this_date = (datetime.datetime.strptime(date_str, '%Y-%m-%d'))

            if this_date < right_now:
                continue

            if this_date > last_date:
                last_date = copy.copy(this_date)

            total_sum_owed += float(cpr['saldo_devedor'])
            op_count += 1

        new_row = {'doc': doc, 'saldo_devedor': total_sum_owed, 'ultima_data': last_date.strftime(format='%d/%m/%Y'),
                   'qtd_ops': str(op_count)}
        df_flat_cpr.loc[len(df_flat_cpr)] = new_row

    return df_flat_cpr
