import re
import pandas as pd
from data_processing import datalake
import fluid
import misc
from data_processing import grupo_economico, doc_handler

credentials = misc.get_datalake_api_credentials()


def get_membros(process_id: int, doc_proponente: str):

    # roles
    df_roles = pd.DataFrame()
    df_roles = pd.concat([df_roles, pd.DataFrame({'role_name': 'Proponente'}, index=[0])])
    df_roles = pd.concat([df_roles, pd.DataFrame({'role_name': 'Avalista'}, index=[1])])
    df_roles = pd.concat([df_roles, pd.DataFrame({'role_name': 'Grupo econômico'}, index=[2])])

    # construir dataframe dos membros
    df_membros = pd.DataFrame()
    df_membros['doc_c'] = None
    df_membros['doc_s'] = None
    df_membros['doc_type'] = None
    df_membros['role'] = None
    df_membros['role_name'] = None
    df_membros['name'] = ''

    # add. proponente
    role_prop = 0
    doc_proponente = doc_handler.format_cpf_cnpj(doc=doc_proponente)
    new_row = {'doc_c': doc_proponente, 'role': role_prop, 'role_name': df_roles.at[role_prop, 'role_name']}
    df_membros = pd.concat([df_membros, pd.DataFrame(new_row, index=[df_membros.shape[0]])])

    # add. avalistas
    role_aval = 1
    df_avalistas = fluid.get_avalistas_table(process_id=process_id)
    for idx, aval in df_avalistas.iterrows():
        doc = doc_handler.format_cpf_cnpj(aval['CPF/CNPJ'])
        is_membro = df_membros['doc_c'].str.contains(doc).any()
        if is_membro:
            continue
        new_row = {'doc_c': doc, 'role': role_aval, 'role_name': df_roles.at[role_aval, 'role_name']}
        df_membros = pd.concat([df_membros, pd.DataFrame(new_row, index=[df_membros.shape[0]])])

    # add. gr. eco.
    role_grupo_eco = 2
    df_grupo_eco, is_groupless = grupo_economico.get_data_for_grupo_eco(doc=doc_proponente)
    for idx, greco in df_grupo_eco.iterrows():
        doc = doc_handler.format_cpf_cnpj(doc=greco['num_cpf_cnpj'])
        is_membro = df_membros['doc_c'].str.contains(doc).any()
        if is_membro:
            continue
        new_row = {'doc_c': doc, 'role': role_grupo_eco, 'role_name': df_roles.at[role_grupo_eco, 'role_name']}
        df_membros = pd.concat([df_membros, pd.DataFrame(new_row, index=[df_membros.shape[0]])])
    pass

    for index, member in df_membros.iterrows():
        # formatar doc configurado
        doc = member['doc_c']
        doc = doc_handler.format_cpf_cnpj(doc)
        df_membros.at[index, 'doc_c'] = doc
        df_membros.at[index, 'doc_type'] = doc_handler.get_doc_type(doc)

        # formatar doc sem formatacao
        clear_doc_pattern = r"[^\d]"
        doc = re.sub(pattern=clear_doc_pattern, string=doc, repl='')
        df_membros.at[index, 'doc_s'] = doc

    df_membros = get_names_for_members(df_membros=df_membros)
    # noinspection PyBroadException
    try:
        df_membros = get_names_for_members(df_membros=df_membros)
    except:
        print("Não foi possível pegar nomes de membros")

    return df_membros


# noinspection PyBroadException
def get_names_for_members(df_membros):
    df_visao_geral = datalake.get_data_in_datalake(arg_list=df_membros['doc_s'].tolist(), table_name='cadastro_visao_geral_associado_light_rls', target_column='num_cpf_cnpj')

    # filtrar cols
    df_visao_geral = df_visao_geral[['num_cpf_cnpj', 'nom_associado']]
    df_visao_geral = df_visao_geral.drop_duplicates()

    # atribuir nomes achados
    for index, membro in df_membros.iterrows():
        doc = membro['doc_s']
        aux_df = df_visao_geral.loc[df_visao_geral['num_cpf_cnpj'] == doc].reset_index(drop=True)
        if aux_df.shape[0] > 0:
            name = aux_df.at[0, 'nom_associado']
            df_membros.at[index, 'name'] = name

    return df_membros