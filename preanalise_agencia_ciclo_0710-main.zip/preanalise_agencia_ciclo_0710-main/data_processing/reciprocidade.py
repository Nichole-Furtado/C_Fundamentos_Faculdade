from datetime import datetime
import locale
import pandas as pd
from data_processing import datalake

locale.setlocale(locale.LC_ALL, 'pt_BR.UTF-8')


def get_reciprocidade_grupo(df_membros):
    df_reciprocidade = pd.DataFrame()
    df_reciprocidade['Nome'] = None
    df_reciprocidade['CPF/CNPJ'] = None
    df_reciprocidade['Tempo com a coop.'] = None
    df_reciprocidade['Margem de Contribuíção'] = None
    df_reciprocidade['Nível de risco'] = None
    df_reciprocidade['Principalidade'] = None
    df_reciprocidade['ISA'] = None

    df_base_rel = get_data_from_base_relacionamento(doc_list=df_membros['doc_s'].tolist())

    if df_base_rel.shape[0] == 0:
        data = {"Nenhum dos envolvidos possui dados de relacionamento calculados.":
                "Isso pode ocorrer quando o cadastro dos envolvidos foi criado muito recentemente."}
        df_reciprocidade = pd.DataFrame(data, index=[0])
        return df_reciprocidade

    for idx_m, membro in df_membros.iterrows():

        df_base_rel_aux = df_base_rel[df_base_rel['num_cpf_cnpj'] == membro['doc_s']].reset_index(drop=True)

        if df_base_rel_aux.shape[0] == 0:

            new_row = df_reciprocidade.columns.to_series().to_dict()

            for key in new_row:
                new_row[key] = ''

            new_row['Nome'] = membro['name']

            new_row['CPF/CNPJ'] = membro['doc_c']

            for col in new_row:
                if len(str(new_row[col])) == 0:
                    new_row[col] = 'Não localizado'

            df_reciprocidade.loc[len(df_reciprocidade)] = new_row
            continue

        # Associar valores simples
        doc = membro['doc_c']
        nome = membro['name'] + " [" + membro['role_name'] + "]"
        isa = df_base_rel_aux.at[0, 'isa']
        risco = df_base_rel_aux.at[0, 'nivel_risco']

        # Associar MC
        mc = locale.currency(val=float(df_base_rel_aux.at[0, 'mc_assoc']), symbol=True, grouping=True)

        # Associar tempo com a coop
        # noinspection PyBroadException
        try:
            abertura_data = datetime.strptime(df_base_rel_aux.at[0, 'assoc_desde'], "%Y-%m-%d %H:%M:%S.%f")
        except:
            abertura_data = datetime.strptime(df_base_rel_aux.at[0, 'assoc_desde'], "%Y-%m-%d %H:%M:%S")
        current_datetime = datetime.now()
        time_difference = current_datetime - abertura_data
        years = time_difference.days // 365
        months = (time_difference.days % 365) // 30
        tempo_com_coop = f"{years} anos e {months} meses"
        principalidade = str(df_base_rel_aux.at[0, 'faixa_principalidade'])
        if principalidade.lower() == 'none':
            principalidade = 'Não localizado'

        new_row = {'CPF/CNPJ': doc,
                   'Nome': nome,
                   'ISA': isa,
                   'Principalidade': principalidade,
                   'Tempo com a coop.': tempo_com_coop,
                   'Margem de Contribuíção': mc,
                   'Nível de risco': risco}


        df_reciprocidade.loc[len(df_reciprocidade)] = new_row
    return df_reciprocidade


def get_data_from_base_relacionamento(doc_list: list):
    df = datalake.get_data_in_datalake(arg_list=doc_list,
                                       table_name='base_relacionamento_atual',
                                       target_column='num_cpf_cnpj')
    return df


def get_data_from_visao_geral(doc_list: list):
    df = datalake.get_data_in_datalake(arg_list=doc_list,
                                       table_name='cadastro_visao_geral_associado_light_rls',
                                       target_column='num_cpf_cnpj')
    return df

