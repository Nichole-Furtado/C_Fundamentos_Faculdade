import json
import pandas as pd
import requests
from requests.auth import HTTPBasicAuth
from prefect.blocks.system import JSON, Secret


class DatalakeAPIConfig:
    config = JSON.load("datalake-api-config").value

    def __init__(self):
        self.user_name = DatalakeAPIConfig.config['user_name']
        self.base_uri = DatalakeAPIConfig.config['base_uri']
        self.password = Secret.load(DatalakeAPIConfig.config['password_block']).get()


def get_data_in_datalake(arg_list: list, table_name: str, target_column: str):

    url = f"{api_config.base_uri}/table/{table_name}/{target_column}/in"
    arg_list = ",".join(arg_list)
    querystring = {"value": arg_list}
    auth = HTTPBasicAuth(username=api_config.user_name, password=api_config.password)
    response = requests.request("GET", url, data="", headers={}, params=querystring, auth=auth)

    data = json.loads(response.text)
    dataframe = pd.DataFrame(data['data'])
    return dataframe


api_config = DatalakeAPIConfig()
