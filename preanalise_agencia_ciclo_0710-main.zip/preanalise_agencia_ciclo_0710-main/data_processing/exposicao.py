from data_processing import datalake
import pandas as pd
import locale

locale.setlocale(locale.LC_ALL, 'pt_BR.UTF-8')


def get_exposicao_grupo(df_membros):
    df_exposicao = get_exposicao_from_datalake(df_membros=df_membros)
    if df_exposicao.shape[0] > 0:
        df_exposicao = keep_only_most_recent_per_doc(df=df_exposicao)
        value = float(df_exposicao.at[0, 'exposicao_potencial_grupo'])
        fin_value = locale.currency(float(value), grouping=True, symbol=True)
    else:
        fin_value = 'R$ 0,00'
    df_exposicao = pd.DataFrame()
    df_exposicao['Exposição potencial do grupo:'] = None
    df_exposicao.loc[len(df_exposicao)] = {df_exposicao.columns[0]: fin_value}
    return df_exposicao


def get_exposicao_from_datalake(df_membros):
    return datalake.get_data_in_datalake(arg_list=df_membros['doc_s'].tolist(), table_name='listagem_exposicao_lec',
                                         target_column='cpf_cnpj')


def keep_only_most_recent_per_doc(df):
    df['dat_base'] = pd.to_datetime(df['data_base'], format='%Y-%m-%d')
    df.sort_values(by='data_base', ascending=False, inplace=True)
    df = df.groupby('cpf_cnpj').first().reset_index(drop=True)
    return df
