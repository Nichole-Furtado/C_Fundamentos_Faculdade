import re
import pandas as pd
from data_processing import datalake
from data_processing import doc_handler


def get_data_for_grupo_eco(doc: str):
    doc = re.sub(pattern=r'[^\d]', string=doc, repl='')

    df = datalake.get_data_in_datalake(arg_list=[doc], table_name='cadastro_visao_geral_associado_light_rls', target_column='num_cpf_cnpj')
    df_base = datalake.get_data_in_datalake(arg_list=[doc], table_name='pessoas', target_column='num_cpf_cnpj')
    for idx, cadastro in df.iterrows():
        for indx, base in df_base.iterrows():
            if base['dt_renovacao_cadastral'] == 'None':
                df.at[idx, 'dat_ultima_atualizacao_conta'] = cadastro['dat_abertura_conta']
            else:
                df.at[idx, 'dat_ultima_atualizacao_conta'] = base['dt_renovacao_cadastral']
    if df.shape[0] > 0:
        df['dat_ultima_atualizacao_conta'] = pd.to_datetime(df['dat_ultima_atualizacao_conta'], format='%Y-%m-%d %H:%M:%S')
        df = df.sort_values('dat_ultima_atualizacao_conta', ascending=False).reset_index(drop=True)
        df['dat_ultima_atualizacao_conta'] = df['dat_ultima_atualizacao_conta'].dt.strftime('%Y-%m-%d %H:%M:%S')
        cod_grupo_eco = df.at[0, 'cod_conglomerado_economico']
    else:
        cod_grupo_eco = ''

    if len(cod_grupo_eco) > 0 and not cod_grupo_eco == 'None':
        df = datalake.get_data_in_datalake(arg_list=[cod_grupo_eco], table_name='cadastro_visao_geral_associado_light_rls', target_column='cod_conglomerado_economico')
        for pessoa, grupo in df.iterrows():
            df_base = datalake.get_data_in_datalake([grupo['num_cpf_cnpj']], table_name='pessoas', target_column= 'num_cpf_cnpj')
            for indx, base in df_base.iterrows():
                df.at[pessoa, 'dat_ultima_atualizacao_conta'] = base['dt_renovacao_cadastral']
        is_groupless = False if df.shape[0] > 0 else True
    else:
        is_groupless = True

    return df, is_groupless


def get_grupo_eco_view(df, cols_dict: dict):

    df.columns = df.columns.str.strip()
    # df = df[df['des_status_conta'].str.contains('Ativa')]

    for index, row in df.iterrows():
        doc = doc_handler.format_cpf_cnpj(row['num_cpf_cnpj'])
        df.at[index, 'num_cpf_cnpj'] = doc
        pass

    for col in df.columns:
        if col not in cols_dict:
            df = df.drop(col, axis=1)

    df = df.rename(columns=cols_dict)
    df = df.drop_duplicates()

    return df


def get_grupo(doc_proponente: str):
    cols_dict = {'num_cpf_cnpj': 'CPF/CNPJ',
                 'nom_associado': 'Nome',
                 'num_conta': "Conta corrente",
                 'dat_ultima_atualizacao_conta': 'Data de atualização cadastral',
                 'des_status_conta': 'Status da conta'}

    df, is_groupless = get_data_for_grupo_eco(doc=doc_proponente)
    if is_groupless:
        header = f'Proponente(s): {doc_proponente}'
        row = 'Não possui grupo economico.'
        data = {header: row}
        df_grupo_eco = pd.DataFrame.from_dict(data, orient='index', columns=[header])
    else:
        df_grupo_eco = get_grupo_eco_view(df=df, cols_dict=cols_dict)

    return df_grupo_eco

