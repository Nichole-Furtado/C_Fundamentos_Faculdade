import re
import validate_docbr as docbr


def format_cpf_cnpj(doc: str):

    # remover digitos do documento
    remove_all_but_digits_pattern = r"[^\d]"
    doc = re.sub(pattern=remove_all_but_digits_pattern, string=doc, repl='')

    is_cpf = validate_cpf(cpf=doc)
    is_cnpj = validate_cnpj(cnpj=doc)

    if not is_cpf and not is_cnpj or (is_cnpj and is_cpf):
        raise f"O documento '{doc}' apresenta erros."
    if is_cpf:
        doc = docbr.CPF().mask(doc=doc)
    if is_cnpj:
        doc = docbr.CNPJ().mask(doc=doc)
    
    return doc


def validate_cpf(cpf: str):
    return docbr.CPF().validate(cpf)


def validate_cnpj(cnpj: str):
    return docbr.CNPJ().validate(cnpj)


def get_doc_type(doc: str):
    is_cpf = validate_cpf(cpf=doc)
    is_cnpj = validate_cnpj(cnpj=doc)

    if not is_cpf and not is_cnpj or (is_cnpj and is_cpf):
        raise f"O documento '{doc}' apresenta erros."
    if is_cpf:
        return 'PF'
    if is_cnpj:
        return 'PJ'