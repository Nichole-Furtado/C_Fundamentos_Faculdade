import locale
import pandas as pd
from data_processing import datalake
from misc import *

locale.setlocale(locale.LC_ALL, 'pt_br.UTF-8')
credentials = get_datalake_api_credentials()


def query_to_datalake_at_bens(doc_list: list):

    df = datalake.get_data_in_datalake(arg_list=doc_list, target_column='cpf_cnpj', table_name='bens_por_associado')

    # tirar coluna de descricao, texto mto extenso...
    if 'descricao_bem' in df.columns:
        df = df.drop('descricao_bem', axis=1)

    return df


def get_patrimonio_grupo(df_membros):

    # requisicao do datalake para pegar dados
    df_bens = query_to_datalake_at_bens(doc_list=df_membros['doc_s'].tolist())

    # lista de dataframes para saida
    dataframes = []

    # definir se df_bens tem linhas
    if df_bens.shape[0] > 0:
        # processamento de soma inicial
        df_patrimonio = process_patrimonio(df_membros=df_membros, df_bens=df_bens)

        # manter zerados em df_zero
        df_zero = df_patrimonio.loc[df_patrimonio['Total'] == 0].reset_index(drop=True)
        df_zero = make_view_zero(df_zero)

        # manter patrimonios > 0 em df_patrimonio
        df_patrimonio = df_patrimonio.loc[df_patrimonio['Total'] > 0].reset_index(drop=True)
        df_total = make_view_total(df_patrimonio)  # compor resumo do total enquanto valores sao float
        df_patrimonio = make_view_patrimonio_grupo(df_patrimonio=df_patrimonio)

        # add a lista em ordem para geracao de HTML posterior...
        dataframes.append(df_total)
        dataframes.append(df_patrimonio)
        dataframes.append(df_zero)
    else:
        data = {'Situação cadastral do patrimônio': ['Nenhum dos envolvidos teve patrimônio localizado em nossas bases.']}
        df_patrimonio = pd.DataFrame(data)
        dataframes.append(df_patrimonio)
        pass

    return dataframes


def process_patrimonio(df_membros, df_bens):
    # listar tipos de
    types = df_bens['tipo_bem'].unique()
    types = types.astype(str).tolist()

    if 'OUTROS' in types:
        types.remove('OUTROS')

    # --- criar esqueleto do dataframe do ---#
    df_patrimonio = pd.DataFrame()
    df_patrimonio['CPF/CNPJ'] = None
    df_patrimonio['Nome'] = None
    for idx_p, membro in df_membros.iterrows():
        new_row = {'Nome': membro['name'] + " [" + membro['role_name'] + "]", 'CPF/CNPJ': membro['doc_c']}
        df_patrimonio = pd.concat([df_patrimonio, pd.DataFrame(new_row, index=[df_patrimonio.shape[0]])])
    for bem_type in types:
        df_patrimonio[bem_type] = None
    if len(types) > 1:
        df_patrimonio['Total'] = None

    # --- realizar soma
    for idx_p, row in df_patrimonio.iterrows():
        doc = df_membros.loc[df_membros['doc_c'] == row['CPF/CNPJ']].reset_index(drop=True).at[0, 'doc_s']
        df_bens_this_doc = df_bens.loc[df_bens['cpf_cnpj'] == doc]
        total_this_doc = 0
        for col in df_patrimonio.columns:
            if not col in types:
                continue
            df_bens_this_doc_this_type = df_bens_this_doc.loc[df_bens_this_doc['tipo_bem'] == col].reset_index(drop=True)
            total_this_type_this_doc = 0
            for idx_b, bem in df_bens_this_doc_this_type.iterrows():
                percentage = bem['percentual_participacao']
                if is_float(string=percentage):
                    percentage = float(percentage)
                else:
                    percentage = 100
                value_bem = bem['vlr_bem_total']
                if is_float(string=value_bem):
                    value_bem = float(value_bem)
                else:
                    continue
                value_bem = value_bem / 100 * percentage
                total_this_type_this_doc = value_bem + total_this_type_this_doc
                total_this_doc = value_bem + total_this_doc
                pass
            df_patrimonio.at[idx_p, col] = total_this_type_this_doc
        df_patrimonio.at[idx_p, 'Total'] = total_this_doc
    return df_patrimonio


def make_view_patrimonio_grupo(df_patrimonio):
    # transformar em monetario
    df_patrimonio['Total'] = df_patrimonio['Total'].astype(str)
    df_patrimonio = df_patrimonio.reset_index(drop=True)
    for idx, row in df_patrimonio.iterrows():
        idx_col = 0
        for col in df_patrimonio.columns:
            if is_float(row[col]) and idx_col > 1:
                formatted_value = locale.currency(float(row[col]), grouping=True, symbol=True)
                df_patrimonio.at[idx, col] = formatted_value
            idx_col += 1
    return df_patrimonio


def make_view_total(df_patrimonio):

    df_total = pd.DataFrame()

    # total geral
    total = df_patrimonio['Total'].sum()
    total = locale.currency(float(total), grouping=True, symbol=True)
    df_total.at[0, 'Patrimônio total do grupo'] = total

    # total pf
    total_pf = df_patrimonio.loc[~df_patrimonio['CPF/CNPJ'].str.contains("/")]['Total'].sum()
    total_pf = locale.currency(float(total_pf), grouping=True, symbol=True)
    df_total.at[0, 'Patrimônio total entre PFs'] = total_pf

    # total pj
    total_pj = df_patrimonio.loc[df_patrimonio['CPF/CNPJ'].str.contains("/")]['Total'].sum()
    total_pj = locale.currency(float(total_pj), grouping=True, symbol=True)
    df_total.at[0, 'Patrimônio total entre PJs'] = total_pj

    return df_total


def make_view_zero(df_zero):
    df = pd.DataFrame()
    col_name = f'Há {str(df_zero.shape[0])} membros com patrimônio zerado no cadastro (Bens cadastrados com tipo OUTROS não serão considerados)'
    df[col_name] = ''
    for index, membro in df_zero.iterrows():
        str_membros_zero = f"{membro['Nome']} ({membro['CPF/CNPJ']})"
        df = pd.concat([df, pd.DataFrame({col_name: str_membros_zero}, index=[df.shape[0]])])
    return df
