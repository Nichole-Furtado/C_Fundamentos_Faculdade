/*4) Escreva um programa em linguagem C que leia a idade, a altura e o peso de 5 pessoas. O programa deve calcular e mostrar:
a. A quantidade de pessoas com idade superior a 50 anos.
b. A altura média das pessoas com idade entre 10 e 20 anos.
c. O percentual de pessoas com peso inferior à 60 quilos.


contadores = 0, somadores = 0, multiplicadores = 1     */

#include <stdio.h>

int main(void) {
  int idade, i, idade50anos = 0, idade10a20anos = 0, contador_Peso = 0;
  float altura, peso, alturaTotal10a20anos = 0;

  for(i = 1; i <= 5; i++){  //laço de repetição para 5 pessoas o i++ é a mesma coisa que i = i + 1 que significa que o i vai aumentando de 1 em 1 até chegar em 5 
printf("Digite a idade:");
      scanf("%d", &idade);

      printf("Digite a altura:");
      scanf("%f", &altura);

      printf("Digite o peso:");
      scanf("%f", &peso);

      if (idade > 50) {
          idade50anos++; // contador
      }

      if (idade >= 10 && idade <= 20) {
          idade10a20anos++;
        alturaTotal10a20anos += altura; // somador e contador, contador vai contar quantas vezes o laço de repetição foi executado, somador vai somar todas as alt, somatorio1020 = somatorio1020 + altura
      }

      if (peso < 60) {
          contador_Peso++;
      }
  }
printf("a. A quantidade de pessoas com idade superior a 50 anos é: %d\n", idade50anos);

if (idade10a20anos > 0) {
    printf("b. A altura média das pessoas com idade entre 10 e 20 anos é: %.2f\n", alturaTotal10a20anos / idade10a20anos); 
} else {
    printf("b. Não há pessoas com idade entre 10 e 20 anos.\n");
}

printf("c. O percentual de pessoas com peso inferior à 60 quilos é: %.2f%%\n", (contador_Peso * 20.0) / 5); 

  return 0;
}


#include <stdio.h>

int main(void) {
float idade,altura,peso,media_alt,i,cont_peso=0,soma_alt=0,cont_alt10_20=0,cont_idade50=0;

  for (i=0; i<5; i++){

    printf("Digite sua idade:");
    scanf("%f",&idade);
    printf("Digite sua altura:");
    scanf("%f",&altura);
    printf("Digite seu peso:");
    scanf("%f",&peso);

    printf("\n");

    if(idade>50){
      cont_idade50++;
    }
    if(idade>=10 && idade<=20){
      cont_alt10_20++;
      soma_alt=soma_alt+altura;

    }
    if(peso<60){
      cont_peso++;
    }
  }
  printf("pessoas com mais de 50 anos: %2.f\n\n",cont_idade50);

  if(soma_alt != 0){
    media_alt=soma_alt/cont_alt10_20;
    printf("media de altura das pessoas com idade  entre 10 e 20 anos: %2.f\n\n",media_alt);
  }


  if(cont_peso!=0){
    cont_peso=cont_peso/l*100;

    printf("o percentual de pessoas com menos de 60 kilos: %2.f%%\n\n",cont_peso);
  }


  return 0;
}