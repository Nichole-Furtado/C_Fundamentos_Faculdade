#include <stdio.h>

int main(void) {
   int x = 1;
  while (x <= 100){
    if(x % 5 == 0) // == é igual, != é diferente
      printf("%d\n", x);
      x++;

  }

  return 0;
}