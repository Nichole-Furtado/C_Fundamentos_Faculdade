//2) Faça um programa que leia 10 inteiros e imprima sua média.

#include <stdio.h>

int main(void) {
   float média, soma, n;
   int i;
   soma = 0;
   for (i = 1; i <= 10; i++){
     printf("Digite um número: ");
     scanf("%f", &n);
     soma = soma + n;
   }
   média = soma / 10;
   printf("A média é: %.0f", média);
  return 0;
}