/*1-Escreva um programa que solicite ao usuário um número e, em seguida, imprima a
tabuada desse número de 1 a 10. */

// FOR!!

/* #include <stdio.h>

int main(void) {
  int Número, i=1;

  printf ( "Escreva um número, e logo em seguida, a tabuada desse número de 1 a 10 será mostrada:\n ");
  scanf( "%i", &Número);

    for (int i = 1; i <= 10; i++){
      printf("%i x %i = %d\n", Número, i, Número * i);
    }
  
  return 0;
} */

/*1-Escreva um programa que solicite ao usuário um número e, em seguida, imprima a
tabuada desse número de 1 a 10. */

// WHILE!!

#include <stdio.h>

int main(void) {
  int Número, i=1;

  printf ( "Escreva um número, e logo em seguida, a tabuada desse número de 1 a 10 será mostrada:\n ");
  scanf( "%i", &Número);

    while(i <= 10){
      printf("%i x %i = %i\n", Número, i, Número * i);
      i++;
    }

  return 0;
}
