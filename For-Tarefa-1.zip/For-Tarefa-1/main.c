//1) Escrever um programa que o usuário digite 5 valores, um de cada vez, e conta quantos destes valores são negativos, imprimindo esta informação na tela.

#include <stdio.h>

int main(void) {
   int i=1, valor, contador = 0;

  for( i=1; i<=5; i++){
    printf( "Digite um número: ");
    scanf( "%i", &valor);
   if( valor < 0){
     contador ++;
       }
  }
      printf( "Foram digitados %i números negativos", contador);


  return 0;
}