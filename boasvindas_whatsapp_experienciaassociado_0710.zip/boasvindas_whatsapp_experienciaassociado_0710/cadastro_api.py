import json
import urllib3
import warnings
import pandas as pd
import requests
from prefect.blocks.system import JSON, Secret, String
from prefect import task
import getpass
import datetime

dir_cer = String.load("api-coop-0710-cer").value
dir_key = String.load("api-coop-0710-key").value

class CadastroAPIConfig:
    config = JSON.load("rpa-api-0710-config").value

    def __init__(self):
        self.client_id = CadastroAPIConfig.config['client_id']
        self.client_secret = CadastroAPIConfig.config['client_secret']
        self.username = CadastroAPIConfig.config['username']
        self.password = Secret.load(CadastroAPIConfig.config['password']).get()


class CadastroAPIToken:
    def __init__(self, in_token: str):
        self.access_token = in_token
        self.generated_at = datetime.datetime.now()


@task(name="get_cadastro_api_token", log_prints=True)
def get_cadastro_api_token():
    url_autenticacao = "https://api-coop.sicredi.com.br/cooperativas/auth/realms/api-coop-auth/protocol/openid-connect/token"
    payload = (f'grant_type=password&client_id={api_config.client_id}'
               f'&client_secret={api_config.client_secret}'
               f'&username={api_config.username}'
               f'&password={api_config.password}'
               f'&scope=openid')
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'x-api-coop-user': 'ldap_colaborador',
        'x-api-coop-numero': '0710',
        'x-api-coop-aplicacao': 'XP_ASSOC'
    }

    warnings.filterwarnings("ignore", category=urllib3.exceptions.InsecureRequestWarning)
    response = requests.request("POST", url_autenticacao, headers=headers, data=payload).json()

    cadastro_api_token = CadastroAPIToken(in_token=response['access_token'])

    return cadastro_api_token


def keep_token_active(cadastro_api_token):
    timespan = datetime.datetime.now() - cadastro_api_token.generated_at
    if timespan.total_seconds() > 250:
        cadastro_api_token = get_cadastro_api_token()
    return cadastro_api_token


def get_cadastro_info(in_token: str, doc: str):

    url = f"https://mtls-api-coop.sicredi.com.br/cadastro-open-api/api/v1/telefones?documento={doc}"

    headers = {'Authorization': f'Bearer {in_token}',
               'x-api-coop-user': 'ldap_colaborador',
               'x-api-coop-numero': '0710',
               'x-api-coop-aplicacao': 'XP_ASSOC_WHATSAPP_ENTERPRISE_MSG'}

    warnings.filterwarnings("ignore", category=urllib3.exceptions.InsecureRequestWarning)
    response = requests.request("GET", url, headers=headers, data={}, cert=(dir_cer, dir_key), verify=False)

    if str(response.status_code).startswith("20"):
        data = json.loads(response.text)
        assoc_name = data['nome']
        telefones = data['telefones']
        df_cadastro = pd.DataFrame(telefones)
        df_cadastro['nome'] = assoc_name
        result_word = 'Sucesso'
    else:
        result_word = 'Falha'
        df_cadastro = pd.DataFrame()

    print(f"cadastro_api @{str(response.status_code)} - {result_word} ao consultar telefones do documento {doc}")
    return df_cadastro


@task(name="get_basic_cadastro_info", log_prints=True)
def get_basic_cadastro_info(in_token: str, doc: str):
    cadastro_assoc = {'ddd': '', 'numero': ''}

    df_cadastro = get_cadastro_info(in_token=in_token, doc=doc)

    if not df_cadastro.shape[0]:
        return cadastro_assoc

    df_cadastro = df_cadastro[df_cadastro['tipo'] == 'MOVEL'].reset_index(drop=True)
    if not df_cadastro.shape[0]:
        return cadastro_assoc

    cadastro_assoc = {'nome': str(df_cadastro.at[0, 'nome']).title(), 'ddd': df_cadastro.at[0, 'ddd'], 'numero': df_cadastro.at[0, 'numero'], 'nome_associado': str(df_cadastro.at[0, 'nome']).title()}
    return cadastro_assoc


api_config = CadastroAPIConfig()