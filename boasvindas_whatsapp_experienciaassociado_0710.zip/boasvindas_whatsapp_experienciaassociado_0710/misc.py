def log_step(step: str):
    print("")
    print(step)
    print("")


def get_empty_result_obj():
    return {'coop': '',
            'ag': '',
            'doc': '',
            'nome': '',
            'cc': '',
            'telefone': '',
            'plataforma': '',
            'data_envio': '',
            'is_msg_sent': '',
            'status': ''}


class AssocInfo:
    def __init__(self, cadastro_assoc, conta):
        self.cadastro_assoc = cadastro_assoc
        self.conta = conta

    def nome(self):
        nome = ''
        if 'override_name' in self.conta.keys():
            if len(str(self.conta['override_name'])) > 0 and not str(self.conta['override_name']) == 'None':
                nome = str(self.conta['override_name'])
        if not len(nome) > 0:
            nome = str(self.cadastro_assoc['nome'])
        return nome

    def telefone(self):
        telefone_assoc = str(self.cadastro_assoc.get('ddd', '')) + str(self.cadastro_assoc.get('numero', ''))
        return telefone_assoc

    def doc(self):
        doc = str(self.conta['cpf_cnpj'])
        return doc

    def cc(self):
        cc = str(self.conta['num_conta'])
        return cc

    def cod_ag(self):
        cod_ag = str(self.conta['cod_agencia'])
        return cod_ag

    def plataforma(self):
        plataforma = str(self.conta['des_marca'])
        return plataforma

    def coop(self):
        coop = str(self.conta['cod_cooperativa'])
        return coop
