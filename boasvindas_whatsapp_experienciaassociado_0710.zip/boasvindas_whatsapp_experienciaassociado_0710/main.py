import datetime
import time
import pandas as pd
from prefect import flow, task
from prefect.blocks.system import JSON
from prefect.filesystems import LocalFileSystem
import cadastro_api
import contas
import doc_handler
import misc
import smtp_mail
from contas import get_contas, cleanup_masters, add_to_first_msg_master
from misc import log_step, AssocInfo
from whatsapp import send_whatsapp_msg, get_msg_status

dir_folder_boas_vindas = LocalFileSystem.load("dir-folder-boasvindas-whatsapp-experienciaassociado-0710").basepath
timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H-%M')
dir_not_sent_msgs_sheet = f'{dir_folder_boas_vindas}\\{timestamp} mensagens_nao_enviadas.csv'
dir_sent_msgs_sheet = f'{dir_folder_boas_vindas}\\{timestamp} mensagens_enviadas_com_sucesso.csv'


@flow(name='boasvindas_whatsapp_experienciaassociado_0710', log_prints=True)
def main_fn():
    # Inicialização das listas de execução  #
    cleanup_masters()
    # df_first = get_contas()
    df_first, df_second = get_contas()
    token_cadastro_api = cadastro_api.get_cadastro_api_token()

    # Consumo da lista de destinatários da primeira mensagem  #
    log_step(f"--- LOOP DAS PRIMEIRAS MENSAGENS ({str(df_first.shape[0])} rows p/ envio...) ---")
    template_name = 'boasvindas_vanguarda'

    # Inicialização dos relatórios da execução
    header_template = {'coop': [],
                       'ag': [],
                       'doc': [],
                       'nome': [],
                       'cc': [],
                       'telefone': [],
                       'plataforma': [],
                       'data_envio': [],
                       'is_msg_sent': [],
                       'status': []}
    df_sent_msgs = pd.DataFrame(header_template)
    df_not_sent_msgs = pd.DataFrame(header_template)
    array_already_sent = []

    for idx, conta in df_first.iterrows():

        date_sent = datetime.datetime.now().strftime("%Y/%d/%m %H:%M:%S")

        @task(name=f"msg_boas_vindas@{conta['num_conta']}", log_prints=True)
        def msg_boas_vindas():

            # noinspection PyBroadException
            try:
                print(" - - - - - - - - - - - - - - - - - - - - - - - - - - - ")

                result = misc.get_empty_result_obj()

                df_master_first = contas.get_first_master_df()
                in_token_cadastro_api = cadastro_api.keep_token_active(token_cadastro_api)
                cadastro_assoc_ = cadastro_api.get_basic_cadastro_info(
                    in_token=in_token_cadastro_api.access_token,
                    doc=str(conta['cpf_cnpj'])
                )
                assoc_info = AssocInfo(cadastro_assoc=cadastro_assoc_, conta=conta)

                result = {
                    'tipo_msg': 'msg_boas_vindas',
                    'coop': assoc_info.coop(),
                    'ag': assoc_info.cod_ag(),
                    'doc': assoc_info.doc(),
                    'nome': assoc_info.nome(),
                    'nome_associado': assoc_info.nome_associado(),
                    'cc': assoc_info.cc(),
                    'telefone': assoc_info.telefone(),
                    'plataforma': assoc_info.plataforma(),
                    'data_envio': date_sent,
                    'is_msg_sent': False,
                    'status': 'Envio ainda não foi tentado'
                }

                if str(result['cc']) in df_master_first['conta'].values:
                    result['status'] = f"O telefone {assoc_info.telefone()} já recebeu mensagens nos últimos 5 dias."
                    return result

                if assoc_info.telefone() in array_already_sent:
                    result['status'] = (f"O telefone {assoc_info.telefone()} já recebeu mensagens mais cedo. "
                                        f"É possível que esteja registrado no cadastro de múltiplas contas")
                    return result

                if doc_handler.validate_cnpj(cnpj=assoc_info.doc()):
                    result['status'] = f"O doc. {assoc_info.doc()} é CNPJ. Não será possível encontrar um telefone"
                    return result

                print("Iniciando conta " + assoc_info.cc() + ", telefone: " + assoc_info.telefone())

                fields = {
                    'ASSOCIADO': assoc_info.nome(),
                }
                future = send_whatsapp_msg.submit(
                    telefone=assoc_info.telefone(),
                    template_name=template_name,
                    template_fields=fields,
                    in_token=in_token_cadastro_api.access_token,
                    cod_agencia=conta['cod_agencia'],
                    nome= conta['nome'],
                    num_conta=conta['num_conta'],
                    nome_associado=assoc_info.nome_associado(),
                )
                result_id, error_msg = future.result()

                if len(result_id) > 0:
                    is_msg_sent, result_status = get_msg_status(result_id=result_id, telefone=assoc_info.telefone(), in_token=in_token_cadastro_api.access_token)
                else:
                    is_msg_sent = False
                    result_status = error_msg

                result['status'] = result_status
                result['is_msg_sent'] = is_msg_sent

                return result

            except Exception as e:
                campo_faltante = ""
                if not conta.get('cod_agencia'):
                    campo_faltante = "cod_agencia não encontrado"
                elif not conta.get('nome_associado'):
                    campo_faltante = "nome_associado não encontrado"
                elif not conta.get('cpf_cnpj'):
                    campo_faltante = "cpf_cnpj não encontrado"
                elif not conta.get('num_conta'):
                    campo_faltante = "num_conta não encontrado"
                elif not conta.get('des_marca'):
                    campo_faltante = "des_marca não encontrado"
                else:
                    campo_faltante = "Campo não identificado"


                data = {
                    'tipo_msg': 'msg_quatro_dias',
                    'coop': conta.get('cod_cooperativa', '0710'),
                    'ag': conta.get('cod_agencia', 'Não localizado'),
                    'doc': conta.get('cpf_cnpj', 'Não localizado'),
                    'nome': conta.get('nome_associado') or conta.get('nome') or 'Não localizado',
                    'cc': conta.get('num_conta', 'Não localizado'),
                    'telefone': conta.get('telefone', 'Não localizado'),
                    'plataforma': conta.get('des_marca', 'Não localizado'),
                    'data_envio': date_sent,
                    'is_msg_sent': False,
                    'status': f'Campo não encontrado: {campo_faltante}'
                }
                print('Erro no envio: ')
                print(data)
                print(e)
                return data

        operation = msg_boas_vindas()

        # noinspection PyBroadException
        try:
            if not 'is_msg_sent' in operation:
                operation = misc.get_empty_result_obj()
                operation['is_msg_sent'] = False
        except:
            operation = misc.get_empty_result_obj()

            operation['is_msg_sent'] = False

        if operation['is_msg_sent']:
            time.sleep(5)
            add_to_first_msg_master(operation['cc'])
            df_sent_msgs = add_to_report(df=df_sent_msgs, operation_result=operation)
            # noinspection PyBroadException
            try:
                df_sent_msgs.to_csv(path_or_buf=dir_sent_msgs_sheet, sep=';')
            except:
                print("Não foi possível escrever report")
            array_already_sent.append(operation['telefone'])
        else:
            df_not_sent_msgs = add_to_report(df=df_not_sent_msgs, operation_result=operation)
            # noinspection PyBroadException
            try:
                df_not_sent_msgs.to_csv(path_or_buf=dir_not_sent_msgs_sheet, sep=';')
            except:
                print("Não foi possível escrever report")

    for idx, conta in df_second.iterrows():
        if conta['des_marca'] == 'LEGADO':
            template_name = '0710_manual_de_embarque_legado_novo'
        else:
            template_name = '0710_manual_de_embarque_plataforma_novo'

        date_sent = datetime.datetime.now().strftime("%Y/%d/%m %H:%M:%S")

        @task(name=f"msg_quatro_dias@{conta['num_conta']}", log_prints=True)
        def msg_boas_quatro_dias():

            # noinspection PyBroadException
            try:
                print(" - - - - - - - - - - - - - - - - - - - - - - - - - - - ")

                result = misc.get_empty_result_obj()

                df_master_second = contas.get_second_master_df()
                in_token_cadastro_api = cadastro_api.keep_token_active(token_cadastro_api)
                cadastro_assoc_ = cadastro_api.get_basic_cadastro_info(
                    in_token=in_token_cadastro_api.access_token,
                    doc=str(conta['cpf_cnpj'])
                )
                assoc_info = AssocInfo(cadastro_assoc=cadastro_assoc_, conta=conta)

                result = {
                    'tipo_msg': 'msg_quatro_dias',
                    'coop': assoc_info.coop(),
                    'ag': assoc_info.cod_ag(),
                    'doc': assoc_info.doc(),
                    'nome': assoc_info.nome(),
                    'cc': assoc_info.cc(),
                    'telefone': assoc_info.telefone(),
                    'plataforma': assoc_info.plataforma(),
                    'data_envio': date_sent,
                    'is_msg_sent': False,
                    'status': 'Envio ainda não foi tentado'
                }

                if str(result['cc']) in df_master_second['conta'].values:
                    result['status'] = f"O telefone {assoc_info.telefone()} já recebeu mensagens nos últimos 5 dias."
                    return result

                if assoc_info.telefone() in array_already_sent:
                    result['status'] = (f"O telefone {assoc_info.telefone()} já recebeu mensagens mais cedo. "
                                        f"É possível que esteja registrado no cadastro de múltiplas contas")
                    return result

                if doc_handler.validate_cnpj(cnpj=assoc_info.doc()):
                    result['status'] = f"O doc. {assoc_info.doc()} é CNPJ. Não será possível encontrar um telefone"
                    return result

                print("Iniciando conta " + assoc_info.cc() + ", telefone: " + assoc_info.telefone())

                fields = {'ASSOCIADO': assoc_info.nome(),
                          'nome_associado': assoc_info.nome()}
                result_id, error_msg = send_whatsapp_msg(telefone=assoc_info.telefone(), template_name=template_name,
                                                         template_fields=fields)

                if len(result_id) > 0:
                    is_msg_sent, result_status = get_msg_status(result_id=result_id, telefone=assoc_info.telefone(), in_token=in_token_cadastro_api.access_token)
                else:
                    is_msg_sent = False
                    result_status = error_msg

                result['status'] = result_status
                result['is_msg_sent'] = is_msg_sent

                return result

            except Exception as e:
                campo_faltante = ""
                if not conta.get('cod_agencia'):
                    campo_faltante = "cod_agencia não encontrado"
                elif not conta.get('cpf_cnpj'):
                    campo_faltante = "cpf_cnpj não encontrado"
                elif not conta.get('num_conta'):
                    campo_faltante = "num_conta não encontrado"
                elif not conta.get('des_marca'):
                    campo_faltante = "des_marca não encontrado"
                else:
                    campo_faltante = "Campo não identificado"

                data = {
                    'tipo_msg': 'msg_quatro_dias',
                    'coop': conta.get('cod_cooperativa', '0710'),
                    'ag': conta.get('cod_agencia', 'Não localizado'),
                    'doc': conta.get('cpf_cnpj', 'Não localizado'),
                    'nome': conta.get('nome_associado') or conta.get('nome') or 'Não localizado',  
                    'cc': conta.get('num_conta', 'Não localizado'),
                    'telefone': conta.get('telefone', 'Não localizado'),
                    'plataforma': conta.get('des_marca', 'Não localizado'),
                    'data_envio': date_sent,
                    'is_msg_sent': False,
                    'status': f'Campo não encontrado: {campo_faltante}'
                }
                print('Erro no envio: ')
                print(data)
                print(e)
                return data

        operation = msg_boas_quatro_dias()

        # noinspection PyBroadException
        try:
            if not 'is_msg_sent' in operation:
                operation = misc.get_empty_result_obj()
                operation['is_msg_sent'] = False
        except:
            operation = misc.get_empty_result_obj()

            operation['is_msg_sent'] = False

        if operation['is_msg_sent']:
            add_to_first_msg_master(operation['cc'])
            df_sent_msgs = add_to_report(df=df_sent_msgs, operation_result=operation)
            # noinspection PyBroadException
            try:
                df_sent_msgs.to_csv(path_or_buf=dir_sent_msgs_sheet, sep=';')
            except:
                print("Não foi possível escrever report")
            array_already_sent.append(operation['telefone'])
        else:
            df_not_sent_msgs = add_to_report(df=df_not_sent_msgs, operation_result=operation)
            # noinspection PyBroadException
            try:
                df_not_sent_msgs.to_csv(path_or_buf=dir_not_sent_msgs_sheet, sep=';')
            except:
                print("Não foi possível escrever report")

    # Salvar resumos da execução em sheets .csv

    df_sent_msgs.to_csv(path_or_buf=dir_sent_msgs_sheet, sep=';')
    df_not_sent_msgs.to_csv(path_or_buf=dir_not_sent_msgs_sheet, sep=';')
    send_reports_to_xp_assoc(files_to_attach=[dir_sent_msgs_sheet, dir_not_sent_msgs_sheet])

    # Consumo da lista de destinatários da segunda mensagem #
    # log_step(f"--- LOOP DAS SEGUNDAS MENSAGENS ({str(df_second.shape[0])} rows p/ envio...) ---")
    # print(f" ... Estamos aguardando a criação do template desse tipo de mensagem no BotMaker...")


@task(name='send_reports_to_xp_assoc')
def send_reports_to_xp_assoc(files_to_attach: list):
    json_block = JSON.load("mail-report-config-for-boasvindas-whatsapp-experienciaassociado-0710").value
    smtp_mail.send_reports_to_multiple_contacts(file_paths=files_to_attach,
                                                body=json_block['body'],
                                                subject=json_block['subject'],
                                                mail_list=json_block['receiver_email'])


def add_to_report(df, operation_result):
    df.loc[len(df)] = operation_result
    print(operation_result['status'])
    return df


if __name__ == "__main__":
    main_fn()
