import json
import time
from prefect import task
import requests
from prefect.blocks.system import JSON, Secret
from cadastro_api import dir_cer, dir_key, get_cadastro_api_token
import warnings
import urllib3




class WhatsAppAPIConfig:
    config = JSON.load("whatpsapp-api-config").value

    def __init__(self):
        self.base_uri = WhatsAppAPIConfig.config['base_uri']
        self.apy_key = Secret.load(WhatsAppAPIConfig.config['token_conf']).get()


class BoasVindasConfig:
    config = JSON.load("boasvindas-whatsapp-experienciaassociado-0710-config").value

    def __init__(self):
        self.img_url_boasvindas_vanguarda = BoasVindasConfig.config['img_url_boasvindas_vanguarda']

@task(name='check_optin', log_prints=True)
def check_optin(telefone_assoc: str):
    url = f"{api_config.base_uri}/optin/55{telefone_assoc}"
    headers = {"x-api-key": api_config.apy_key}
    response = requests.request("GET", url, data="", headers=headers)
    data = json.loads(response.text)

    if not 'permissionType' in data:
        return False
    if str(data['permissionType']) == 'ALLOW':
        return True
    else:
        return False


@task(name='send_whatsapp_msg', log_prints=True, retries=3, retry_delay_seconds=60)
def send_whatsapp_msg(telefone: str, template_name: str, template_fields: dict, in_token: str, cod_agencia: str, num_conta: str):

    if template_name == 'boasvindas_vanguarda':
        template_fields['headerImageUrl'] = boas_vindas_config.img_url_boasvindas_vanguarda

    # 3. Corrigir o erro de comparação na função send_whatsapp_msg
    if template_name == '0710_manual_de_embarque_plataforma_novo':
        # Usar atribuição (=) ao invés de comparação (==)
        template_fields['ASSOCIADO'] = template_fields.get('nome_associado', template_fields.get('ASSOCIADO', ''))

    url = f"{api_config.base_uri}/notifications/"

    payload = {
        "customerPhoneNum": f'{telefone}',
        "templateName": template_name,
        "templateParameters": template_fields,
        "originCompany": "coop_0710",
        "customerBranchNum": str(cod_agencia),
        "customerAccountNum": str(num_conta),
        "customerCoopCode": "0710",
        "originSystem": "RPA de Envio de Notificações",
        "originUsername": "",
        "operatorMail": "",
        "sender": "WHATSAPP_SICREDI"
    }
    headers = {'Authorization': f'Bearer {in_token}',
               'x-api-coop-user': 'ldap_colaborador',
               'x-api-coop-numero': '0710',
               'x-api-coop-aplicacao': 'XP_ASSOC_WHATSAPP_ENTERPRISE_MSG'}

    warnings.filterwarnings("ignore", category=urllib3.exceptions.InsecureRequestWarning)
    response = requests.request("POST", url, headers=headers, json=payload, cert=(dir_cer, dir_key), verify=False)

    print(f'whatsapp_api: {response.status_code} - notification@{template_name} -> {telefone}')
    data = json.loads(response.text)
    # noinspection PyBroadException
    try:
        result_id = data['senderResultId']
        error_msg = ''
    except Exception as e:
        result_id = ''
        error_msg = data.get('error', 'Erro desconhecido')

        if isinstance(error_msg, list) and len(error_msg) > 0:
            if 'too many' in str(error_msg[0].get('message', '')).lower():
                print(f"Rate limit detectado para {telefone}. Aguardando...")
                time.sleep(30)

        if 'message' in data:
            error_msg += f" - {data['message']}"
        print(response.text, e)

    return result_id, error_msg


@task(name='get_msg_status', log_prints=True)
def get_msg_status(result_id: str, telefone: str, in_token: str):
    msg_is_sent = False
    result_status = "Confirmação pendente"
    idx = 0
    max_tries = 10
    time.sleep(0.5)

    while not msg_is_sent and idx < max_tries:
        url = f"{api_config.base_uri}/notifications/status/{result_id}"
        headers = {
            'Authorization': f'Bearer {in_token}',
            'x-api-coop-user': 'ldap_colaborador',
            'x-api-coop-numero': '0710',
            'x-api-coop-aplicacao': 'XP_ASSOC_WHATSAPP_ENTERPRISE_MSG'
        }
        
        warnings.filterwarnings("ignore", category=urllib3.exceptions.InsecureRequestWarning)  
        response = requests.request("GET", url, headers=headers, cert=(dir_cer, dir_key), verify=False)

        # Tratamento de JSON com verificação
        try:
            if response.text and not response.text.startswith("Found matching route"):
                data = json.loads(response.text)
            else:
                print(f"Resposta inválida da API para {result_id}: {response.text}")
                result_status = "API retornou resposta inválida"
                break
        except Exception as e:
            print(f"Erro ao decodificar JSON: {e}")
            print(f"Resposta recebida: {response.text}")
            result_status = "Erro ao processar resposta da API"
            break

        # Verificação segura dos campos
        if data.get('sent', False):
            msg_is_sent = True
            result_status = "whatsapp_api - Envio da mensagem confirmado"
            break

        if 'errors' in data:
            msg_is_sent = False
            result_status = f"whatsapp_api - Envio da mensagem falhou: {str(data['errors'])}"
            break

        if data.get('requested', False) and not data.get('sent', False):
            time.sleep(1)
            result_status = f"whatsapp_api - Possível falha no BotMaker. Não foi possível confirmar o envio do id {result_id} para o telefone {telefone}."

        idx += 1

    print(f"{result_id} {('não foi' if not msg_is_sent else '')} enviado. {result_status}")
    return msg_is_sent, result_status




def is_phone_valid(ddd: str, numero: str):
    has_numero_correct_length: bool = 7 < len(numero) < 11
    has_ddd_correct_length: bool = len(ddd) == 2
    if has_ddd_correct_length and has_numero_correct_length:
        return True
    else:
        return False


api_config = WhatsAppAPIConfig()
boas_vindas_config = BoasVindasConfig()

