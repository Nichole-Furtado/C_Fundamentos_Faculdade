import json
import pandas as pd
import requests
from prefect.blocks.system import JSON, Secret
from requests.auth import HTTPBasicAuth


class DatalakeAPIConfig:
    config = JSON.load("datalake-api-config").value

    def __init__(self):
        self.user_name = DatalakeAPIConfig.config['user_name']
        self.base_uri = DatalakeAPIConfig.config['base_uri']
        self.password = Secret.load(DatalakeAPIConfig.config['password_block']).get()


def get_data_socios_pj(conta_pj: str):

    url = f"{api_config.base_uri}/table/socios_acionistas_pj/conta_empresa/eq/{str(conta_pj)}"
    auth = HTTPBasicAuth(username=api_config.user_name, password=api_config.password)

    response = requests.request("GET", url, data="", headers={}, auth=auth)

    data = json.loads(response.text)
    df_socios = pd.DataFrame(data['data'])

    return df_socios


def get_data_contas_analitico(doc_list: list):

    url = f"{api_config.base_uri}/table/contas_analitico/cpf_cnpj/in"
    doc_list = ",".join(doc_list)
    querystring = {"value": doc_list}
    auth = HTTPBasicAuth(username=api_config.user_name, password=api_config.password)
    response = requests.request("GET", url, data="", headers={}, params=querystring, auth=auth)

    data = json.loads(response.text)
    df_socios = pd.DataFrame(data['data'])
    return df_socios


api_config = DatalakeAPIConfig()
pass