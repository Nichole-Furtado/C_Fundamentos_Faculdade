import csv
import re
import pyarrow
import pandas as pd
import os
import datetime
import doc_handler
import datalake_requests
import misc
from varname import nameof
from datalake_requests import get_data_socios_pj
from prefect.filesystems import LocalFileSystem
from prefect import task

folder_datalake_backups = LocalFileSystem.load("dir-folder-datalake-backups").basepath
folder_folder_boas_vindas = LocalFileSystem.load("dir-folder-boasvindas-whatsapp-experienciaassociado-0710").basepath
dir_contas_analitico = f"{folder_datalake_backups}\\contas_analitico.parquet"
dir_master_first_msg = f"{folder_folder_boas_vindas}\\master_first_msg.csv"
dir_master_second_msg = f"{folder_folder_boas_vindas}\\master_second_msg.csv"
folder_daily_backup = f"{folder_folder_boas_vindas}\\daily_backups"
days_for_general_threshold = 10
col_abertura = "dat_abertura"


now = datetime.datetime.now()
ten_days_ago = now - datetime.timedelta(days=10)
five_days_ago = now - datetime.timedelta(days=5)
one_day_ago = now - datetime.timedelta(days=1)
ten_days_ago = ten_days_ago.replace(hour=0, minute=0, second=0, microsecond=0)
one_day_ago = one_day_ago.replace(hour=0, minute=0, second=0, microsecond=0)
five_days_ago = five_days_ago.replace(hour=0, minute=0, second=0, microsecond=0)


@task(name="get_df_contas_analitico", log_prints=True)
def get_df_contas_analitico():

    misc.log_step("--- INICIANDO LEITURA DO PARQUET DE CONTAS_ANALITICO ---")

    start_time = datetime.datetime.now()

    df_contas = pd.read_parquet(path=dir_contas_analitico, engine='pyarrow')
    df_contas = df_contas[df_contas['des_produto'] == 'Corrente']
    data_types = {"dat_abertura": 'datetime64[ns]', 'dat_encerramento': 'datetime64[ns]'}

    df_contas = df_contas.astype(data_types)

    df_contas = filter_time_range(dataframe=df_contas, col_name=col_abertura, final_time=now, initial_time=ten_days_ago, dataframe_name=nameof(df_contas))
    schema = {'num_conta': 'int'}
    df_contas = df_contas.astype(schema)

    end_time = datetime.datetime.now()
    timespan = (end_time - start_time).total_seconds()

    print(f'Parquet de contas_analitico lido em {timespan} segundos. Rows: {str(df_contas.shape[0])}')

    date_str = datetime.datetime.now().strftime("%Y-%m-%d--%H-%M-%S")
    dir_daily_backup = f"{folder_daily_backup}\\contas_analitico_at_{date_str}.csv"

    df_contas_yesterday_only = filter_time_range(dataframe=df_contas, final_time=now, initial_time=one_day_ago, dataframe_name='contas_analitico_yesterday_only', col_name=col_abertura)

    df_contas_yesterday_only.to_csv(path_or_buf=dir_daily_backup, sep=';')

    return df_contas


@task(name="filter_time_range", log_prints=True)
def filter_time_range(dataframe, col_name, initial_time, final_time, dataframe_name):
    rows_before = dataframe.shape[0]
    if not pd.api.types.is_datetime64_any_dtype(dataframe[col_name]):
        dataframe[col_name] = pd.to_datetime(dataframe[col_name])

    dataframe = dataframe[(dataframe[col_name] >= initial_time) & (dataframe[col_name] <= final_time)].reset_index(drop=True)
    rows_after = dataframe.shape[0]

    print(f'{dataframe_name} - filter_time_range {str(initial_time)} >> {str(final_time)}. row_count {str(rows_before)} >> {str(rows_after)}')

    return dataframe


def add_to_master(num_conta: int, master_dir: str):
    if not os.path.exists(master_dir):
        create_master_csv(fullname=master_dir)

    new_row = [num_conta, datetime.datetime.now()]
    with open(master_dir, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(new_row)


def add_to_first_msg_master(num_conta: int):
    master_dir = dir_master_first_msg
    add_to_master(num_conta, master_dir)


def add_to_second_msg_master(num_conta: int):
    master_dir = dir_master_second_msg
    add_to_master(num_conta, master_dir)


@task(name="create_master_csv", log_prints=True)
def create_master_csv(fullname: str):
    with open(fullname, mode='w', newline='') as file:
        writer = csv.writer(file)
        header = ['conta', 'date']
        writer.writerow(header)
        print(f"Novo arquivo master criado em {fullname}")


def get_master_df(in_dir):
    if not os.path.exists(in_dir):
        create_master_csv(fullname=in_dir)

    df_master = pd.read_csv(filepath_or_buffer=in_dir, sep=",", index_col=False)
    if df_master.shape[1] == 0:
        print(f"Nenhuma coluna foi encontrada em {in_dir}.O arquivo será excluído e recriado")
        os.remove(path=in_dir)
        df_master = pd.read_csv(filepath_or_buffer=in_dir, sep=",", index_col=False)
    data_types = {'conta': 'str', 'date': 'datetime64[ns]'}
    df_master = df_master.astype(data_types)
    return df_master


@task(name="get_first_master_df", log_prints=True)
def get_first_master_df():
    dir_master = dir_master_first_msg
    df_first_master = get_master_df(in_dir=dir_master)
    print(f"first_master_msg.csv contém atualmente {str(df_first_master.shape[0])} rows (duplicatas são previstas e poderão acontecer).")
    return df_first_master


@task(name="get_second_master_df", log_prints=True)
def get_second_master_df():
    dir_master = dir_master_second_msg
    df_second_master = get_master_df(in_dir=dir_master)
    print(f"second_master_msg.csv contém atualmente {str(df_second_master.shape[0])} rows (duplicatas são previstas e poderão acontecer).")
    return df_second_master


@task(name="get_not_yet_done_df_first_msg", log_prints=True)
def get_not_yet_done_df_first_msg(in_df_contas_analitico):

    misc.log_step("--- AJUSTES DE DATAFRAME DA PRIMEIRA MENSAGEM ---")

    df_done_first_msg = get_first_master_df()
    schema = {'conta': 'int'}
    df_done_first_msg = df_done_first_msg.astype(schema)

    df_first_msg = filter_time_range(initial_time=five_days_ago, final_time=now, col_name=col_abertura, dataframe=in_df_contas_analitico, dataframe_name=nameof(in_df_contas_analitico))

    rows_before = df_first_msg.shape[0]
    df_first_msg = remove_contas_that_are_in_master(df_contas=df_first_msg, df_master=df_done_first_msg)
    rows_after = df_first_msg.shape[0]
    print(f'Removendo rows de master em {nameof(df_first_msg)} - {str(rows_before)} >> {str(rows_after)}')

    return df_first_msg


@task(name="get_not_yet_done_df_second_msg", log_prints=True)
def get_not_yet_done_df_second_msg(in_df_contas_analitico, df_first_msg):

    misc.log_step("--- AJUSTES DE DATAFRAME DA SEGUNDA MENSAGEM ---")

    df_done_second_msg = get_second_master_df()
    schema = {'conta': 'int'}
    df_done_second_msg = df_done_second_msg.astype(schema)

    df_second_msg = pd.DataFrame()
    df_second_msg = filter_time_range(dataframe=in_df_contas_analitico, initial_time=ten_days_ago, final_time=five_days_ago, col_name=col_abertura, dataframe_name=nameof(df_second_msg))

    rows_before = df_second_msg.shape[0]
    df_second_msg = remove_contas_that_are_in_master(df_contas=df_second_msg, df_master=df_done_second_msg)
    rows_after = df_second_msg.shape[0]
    print(f'Removendo rows de master em {nameof(df_first_msg)} - {str(rows_before)} >> {str(rows_after)}')

    return df_second_msg


def remove_contas_that_are_in_master(df_contas, df_master):
    return df_contas[~df_contas['num_conta'].isin(df_master['conta'])].reset_index(drop=True)


@task(name="cleanup_first_msg_master", log_prints=True)
def cleanup_first_msg_master():
    df_master_first = get_first_master_df()
    df_master_first = filter_time_range(dataframe=df_master_first, initial_time=ten_days_ago, final_time=now, col_name="date", dataframe_name=nameof(df_master_first))
    df_master_first = df_master_first.reset_index(drop=True)
    df_master_first.to_csv(dir_master_first_msg, index=False)
    print("Limpeza de 'master_first_msg.csv' concluída")


@task(name="cleanup_second_msg_master", log_prints=True)
def cleanup_second_msg_master():
    df_master_second = get_second_master_df()
    df_master_second = filter_time_range(dataframe=df_master_second, initial_time=ten_days_ago, final_time=now, col_name="date", dataframe_name=nameof(df_master_second))
    df_master_second = df_master_second.reset_index(drop=True)
    df_master_second.to_csv(dir_master_second_msg, index=False)
    print("Limpeza de 'master_first_msg.csv' concluída")


@task(name="replace_pjs_for_socios_pfs", log_prints=True)
def replace_pjs_for_socios_pfs(df_contas, df_name: str):

    print(f"Iniciando busca de sócios PFs de contas PJ em {df_name}")

    df_contas['override_name'] = None
    df_insert_under = pd.DataFrame()

    for index, conta in df_contas.iterrows():
        is_cnpj = doc_handler.validate_cnpj(str(conta['cpf_cnpj']))
        if not is_cnpj:
            continue

        df_pjs = get_data_socios_pj(conta_pj=str(conta['num_conta']))
        if not df_pjs.shape[0] > 0:
            continue

        nome_empresa = df_pjs.at[0, 'nome_empresa']
        nome_empresa = re.sub(pattern=r'^\d+\s', string=nome_empresa, repl='')

        df_socios = datalake_requests.get_data_contas_analitico(df_pjs['cpf_cnpj_socio'].tolist())
        if not df_socios.shape[0]:
            continue

        df_socios = df_socios[df_socios['des_produto'] == 'Corrente']
        df_socios = df_socios[df_socios['des_produto'] != 'Encerrada']
        if not df_socios.shape[0]:
            continue

        df_socios['override_name'] = nome_empresa

        df_contas.at[index, 'des_status_conta'] = 'excluir'
        if df_insert_under.shape[0] == 0:
            df_insert_under = df_socios.copy()
        else:
            df_insert_under = pd.concat([df_insert_under, df_socios])

        print(f"{str(df_socios.shape[0])} rows de sócios localizadas para a conta PJ {str(conta['num_conta'])}")

    df_contas = pd.concat([df_contas, df_insert_under])
    df_contas = df_contas[df_contas['des_status_conta'] != 'excluir']

    return df_contas


@task(name="get_contas", log_prints=True)
def get_contas():
    df_contas_analitico = get_df_contas_analitico()

    df_first_msg = get_not_yet_done_df_first_msg(in_df_contas_analitico=df_contas_analitico)
    df_first_msg = replace_pjs_for_socios_pfs(df_contas=df_first_msg, df_name=nameof(df_first_msg))
    df_first_msg = remove_contas_that_are_in_master(
        df_contas=df_first_msg, df_master=get_master_df(in_dir=dir_master_first_msg)
    )

    df_second_msg = get_not_yet_done_df_second_msg(
        df_first_msg=df_first_msg, in_df_contas_analitico=df_contas_analitico
    )
    df_second_msg = replace_pjs_for_socios_pfs(df_contas=df_second_msg, df_name=nameof(df_second_msg))

    return df_first_msg, df_second_msg


@task(name="cleanup_masters", log_prints=True)
def cleanup_masters():
    misc.log_step("--- INICIANDO AJUSTES EM ARQUIVOS MASTER ---")
    cleanup_first_msg_master()
    cleanup_second_msg_master()