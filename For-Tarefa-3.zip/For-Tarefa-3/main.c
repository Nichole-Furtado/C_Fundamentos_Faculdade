// 3) Faça um programa que leia um número inteiro positivo N e imprima todos os
// números naturais de 0 até N em ordem decrescente.

#include <stdio.h>

int main(void) {
  int n, i;
  printf("Digite um número inteiro positivo: ");
  scanf("%d", &n);
  if (n < 0) {
    printf("Número inválido");
    return 0;
  }
  for (i = n; i >= 0; i--) {
    printf("%d\n", i);
  }
  return 0;
}